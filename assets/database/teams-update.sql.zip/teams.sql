-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 29, 2015 at 08:58 AM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dolphins`
--

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

DROP TABLE IF EXISTS `teams`;
CREATE TABLE IF NOT EXISTS `teams` (
  `ID` int(11) NOT NULL,
  `TEAMCODE` varchar(3) NOT NULL,
  `NAME` varchar(50) NOT NULL,
  `CONFERENCE` varchar(50) NOT NULL,
  `DIVISION` varchar(50) NOT NULL,
  `IMAGE` varchar(100) DEFAULT NULL,
  `CITY` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`ID`, `TEAMCODE`, `NAME`, `CONFERENCE`, `DIVISION`, `IMAGE`, `CITY`) VALUES
(1, 'MIA', 'Dolphins', 'American Football Conference', 'AFC East', 'MIA_logo-80x90.gif', 'Miami'),
(2, 'NE', 'Patriots', 'American Football Conference', 'AFC East', 'NE_logo-80x90.gif', 'New England'),
(3, 'NYJ', 'Jets', 'American Football Conference', 'AFC East', 'NYJ_logo-80x90.gif', 'New York'),
(4, 'BUF', 'Bills', 'American Football Conference', 'AFC East', 'BUF_logo-80x90.gif', 'Buffalo'),
(5, 'CIN', 'Bengals', 'American Football Conference', 'AFC North', 'CIN_logo-80x90.gif', 'Cincinnati'),
(6, 'PIT', 'Steelers', 'American Football Conference', 'AFC North', 'PIT_logo-80x90.gif', 'Pittsburgh'),
(7, 'CLE', 'Browns', 'American Football Conference', 'AFC North', 'CLE_logo-80x90.gif', 'Cleveland'),
(8, 'BAL', 'Ravens', 'American Football Conference', 'AFC North', 'BAL_logo-80x90.gif', 'Baltimore'),
(9, 'IND', 'Colts', 'American Football Conference', 'AFC South', 'IND_logo-80x90.gif', 'Indianapolis'),
(10, 'JAC', 'Jaguars', 'American Football Conference', 'AFC South', 'JAC_logo-80x90.gif', 'Jacksonville'),
(11, 'HOU', 'Texans', 'American Football Conference', 'AFC South', 'HOU_logo-80x90.gif', 'Houston'),
(12, 'TEN', 'Titans', 'American Football Conference', 'AFC South', 'TEN_logo-80x90.gif', 'Tennessee'),
(13, 'DEN', 'Broncos', 'American Football Conference', 'AFC West', 'DEN_logo-80x90.gif', 'Denver'),
(14, 'OAK', 'Raiders', 'American Football Conference', 'AFC West', 'OAK_logo-80x90.gif', 'Oakland'),
(15, 'SD', 'Chargers', 'American Football Conference', 'AFC West', 'SD_logo-80x90.gif', 'San Diego'),
(16, 'KC', 'Chiefs', 'American Football Conference', 'AFC West', 'KC_logo-80x90.gif', 'Kansas City'),
(17, 'DAL', 'Cowboys', 'National Football Conference', 'NFC East', 'DAL_logo-80x90.gif', 'Dallas'),
(18, 'NYG', 'Giants', 'National Football Conference', 'NFC East', 'NYG_logo-80x90.gif', 'New York'),
(19, 'WAS', 'Redskins', 'National Football Conference', 'NFC East', 'WAS_logo-80x90.gif', 'Washington'),
(20, 'PHI', 'Eagles', 'National Football Conference', 'NFC East', 'PHI_logo-80x90.gif', 'Philadelphia'),
(21, 'GB', 'Packers', 'National Football Conference', 'NFC North', 'GB_logo-80x90.gif', 'Green Bay'),
(22, 'MIN', 'Vikings', 'National Football Conference', 'NFC North', 'MIN_logo-80x90.gif', 'Minnesota'),
(23, 'DET', 'Lions', 'National Football Conference', 'NFC North', 'DET_logo-80x90.gif', 'Detroit'),
(24, 'CHI', 'Bears', 'National Football Conference', 'NFC North', 'CHI_logo-80x90.gif', 'Chicago'),
(25, 'CAR', 'Panthers', 'National Football Conference', 'NFC South', 'CAR_logo-80x90.gif', 'Carolina'),
(26, 'ATL', 'Falcons', 'National Football Conference', 'NFC South', 'ATL_logo-80x90.gif', 'Atlanta'),
(27, 'TB', 'Buccaneers', 'National Football Conference', 'NFC South', 'TB_logo-80x90.gif', 'Tampa Bay'),
(28, 'NO', 'Saints', 'National Football Conference', 'NFC South', 'NO_logo-80x90.gif', 'New Orleans'),
(29, 'ARI', 'Cardinals', 'National Football Conference', 'NFC West', 'ARI_logo-80x90.gif', 'Arizona'),
(30, 'STL', 'Rams', 'National Football Conference', 'NFC West', 'STL_logo-80x90.gif', 'St. Louis'),
(31, 'SF', '49ers', 'National Football Conference', 'NFC West', 'SF_logo-80x90.gif', 'San Francisco'),
(32, 'SEA', 'Seahawks', 'National Football Conference', 'NFC West', 'SEA_logo-80x90.gif', 'Seattle');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=33;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
